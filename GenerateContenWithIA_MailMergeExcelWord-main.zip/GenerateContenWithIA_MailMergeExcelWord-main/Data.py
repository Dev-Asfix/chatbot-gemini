class Texts:
    # Constantes
    API_KEY="AIzaSyC7QlRDfoF5Al7KQAiTGjJrAE79PdLgxT8"
    ACCURACYIL ="Genera un indicador de logro ,utilizando un solo verbo de orden superior en infinitivo según la taxonomía de Bloom. Omite poner titulos o rotulos centrate en lo que se pide, Redacta el indicador en un solo párrafo de este tema " 
    ACCURACY_PROPOSITO ="Genera un propósito de la semana usa el mismo verbo en del indicador de logro, omite titulos y agregale un complemento pero redactamelo en el tiempo verbal imperativo que te proporciono a continuacion, de este tema e indicador de logro "  
    ACCURACYIL_RECURSOS ="Genera un Recurso digital para el aprendizaje y generalo en una sola linea ,  omite poner titulos o rotulos centrate en lo que se pide, las palabras que describen lo mismo como recurso o link. incluye el nombre del recurso y link del mismo, verifica que los recursos y su link sean vigentes es decir que esten activos, de este tema e indicador de logro "   
    ACCURACY_INICIO ="Genera un inicio  para una sesión de aprendizaje, omite poner titulos o rotulos centrate en lo que se pide. Comienza con una intro de un parrafo, Luego plantea dos preguntas que despierten la curiosidad de los participantes y los conecten con el tema. Redacta en primera persona, para este tema e indicador de logro "
    ACCURACY_DESARROLLO ="Genera el desarrollo sesión de aprendizaje, omite poner titulos y tiempos, generame netamente el desarrollo omite introduccion para este tema e indicador de logro "
    ACCURACY_CIERRE="Generame el cierre de la sesion  de aprendizaje, redactalo en primera persona omitiendo caracteres especiales, omite materiales, Concentrate solo en el cierre de las sesion, para este tema"
    '''ACCURACYALL="Generame una sesión de clase detallada y simple en sus tres momentos: Inicio ,Desarrollo y Cierre, solo dame informacion de los tres momentos, de este tema "
    '''

